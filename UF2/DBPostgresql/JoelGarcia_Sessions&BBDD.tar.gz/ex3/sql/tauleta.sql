﻿CREATE TABLE public.tauleta
(
  id integer NOT NULL DEFAULT nextval('tauleta_id_seq'::regclass),
  marca character varying(50),
  model character varying(50),
  color character varying(50),
  ssoo character varying(50),
  preu numeric(6,2),
  imatge character varying(100),
  CONSTRAINT tauleta_pkey PRIMARY KEY (id)
);

INSERT INTO public.tauleta(marca, model, color, ssoo, preu, imatge)
    VALUES ('Xiaomi', 'MiPad2', 'Negro', 'Chino', 295.99, 'Xiaomi.png');
INSERT INTO public.tauleta(marca, model, color, ssoo, preu, imatge)
    VALUES ('Windows', 'Windows', 'Negro', 'Windows 8.1 ', 325.99, 'Windows.png');
INSERT INTO public.tauleta(marca, model, color, ssoo, preu, imatge)
    VALUES ('HP', 'Pro Slate 8', 'Negro', 'Android', 150.99, 'Hp.png');    
INSERT INTO public.tauleta(marca, model, color, ssoo, preu, imatge)
    VALUES ('Apple', 'iPad Mini 2', 'Gris Espacial', 'iOS', 150.99, 'Apple.png');    